# PRD: CyAsset — Aplikasi Manajemen Sarana Prasarana SMK Cyber Media

## Pernyataan Masalah

Petugas Sarana Prasarana (Sarpras) SMK Cyber Media saat ini mengelola data barang, peminjaman, dan laporan kerusakan secara manual (kertas/spreadsheet terpisah-pisah). Ini menyulitkan:

- Melacak lokasi & kondisi barang secara akurat (barang tersebar di banyak gedung/lantai/ruang/lemari).
- Mengetahui barang mana yang sedang dipinjam (di dalam maupun di luar sekolah) dan kapan harus kembali.
- Menerbitkan surat resmi untuk peminjaman ke luar sekolah secara cepat dan konsisten formatnya.
- Menindaklanjuti laporan kerusakan barang secara terstruktur (ada laporan masuk, tapi tidak jelas statusnya sampai mana).
- Menyediakan laporan rekap yang rapi untuk pimpinan (inventaris per ruang, riwayat peminjaman, riwayat perbaikan) tanpa harus rekap manual dari banyak sumber.

## Solusi

CyAsset adalah aplikasi web internal (Next.js + PostgreSQL) yang dioperasikan sepenuhnya oleh **Admin Sarpras** sebagai satu-satunya role berlogin di sistem. Guru, siswa, Kakomli, pihak luar sekolah, dan pimpinan **tidak memiliki akun** — mereka berinteraksi dengan Admin secara langsung/lisan/WhatsApp, dan Admin yang mencatatkan semuanya ke sistem. Ini menyederhanakan sistem menjadi alat pencatatan & pelaporan internal, bukan portal self-service multi-pihak.

Cakupan utama:

1. **Pendataan barang** berbasis form dengan hierarki lokasi 4 tingkat, foto, dan breakdown kondisi (Baik/Rusak Ringan/Rusak Berat) per jumlah unit (model batch/quantity, bukan per-unit individual).
2. **Peminjaman** dua jalur: internal (dalam sekolah) dan eksternal (luar sekolah, dengan generate Surat Peminjaman PDF resmi bernomor otomatis).
3. **Pelaporan kerusakan** berbasis tiket dengan alur status dan dampak otomatis ke stok kondisi barang.
4. **Dashboard & ekspor laporan** (LIR, rekap peminjaman, rekap perbaikan) untuk kebutuhan pimpinan.

## User Stories

### Autentikasi & Manajemen Akun
1. Sebagai Admin Sarpras, saya ingin login dengan username/email dan password, sehingga hanya staf berwenang yang bisa mengakses sistem.
2. Sebagai Admin Sarpras, saya ingin membuat akun staf Sarpras lain, sehingga tim yang terdiri lebih dari satu orang bisa memakai sistem secara bersamaan dengan akun masing-masing.
3. Sebagai Admin Sarpras, saya ingin menonaktifkan akun staf yang sudah tidak bertugas, sehingga akses ke sistem tetap terkendali.
4. Sebagai Admin Sarpras, saya ingin setiap aksi penting (input barang, proses peminjaman, proses laporan) tercatat oleh akun siapa yang melakukannya, sehingga ada jejak audit yang jelas.

### Hierarki Lokasi
5. Sebagai Admin Sarpras, saya ingin mengelola daftar Gedung, sehingga saya bisa merepresentasikan struktur fisik sekolah.
6. Sebagai Admin Sarpras, saya ingin mengelola daftar Lantai di dalam sebuah Gedung, sehingga hierarki lokasi lebih detail.
7. Sebagai Admin Sarpras, saya ingin mengelola daftar Ruang di dalam sebuah Lantai, sehingga saya bisa menentukan ruang spesifik tempat barang berada.
8. Sebagai Admin Sarpras, saya ingin mengelola Sub-lokasi (misal Lemari, Rak) di dalam sebuah Ruang secara opsional, sehingga posisi barang bisa lebih presisi tanpa harus diisi untuk semua barang.
9. Sebagai Admin Sarpras, saya ingin memilih lokasi barang lewat dropdown berjenjang (Gedung → Lantai → Ruang → Sub-lokasi), sehingga input lokasi cepat dan konsisten.

### Pendataan Barang
10. Sebagai Admin Sarpras, saya ingin mendata barang baru lewat form digital, sehingga semua identitas barang tercatat rapi.
11. Sebagai Admin Sarpras, saya ingin mengisi Nama Barang, Merk/Tipe, Kode/Nomor Seri (manual), Jumlah Unit, Kategori, dan Spesifikasi Teknis saat mendata barang, sehingga informasi barang lengkap.
12. Sebagai Admin Sarpras, saya ingin meng-upload foto kondisi fisik barang saat pendataan, sehingga ada bukti visual kondisi awal barang.
13. Sebagai Admin Sarpras, saya ingin menentukan lokasi barang lewat hierarki 4 tingkat, sehingga saya tahu persis di mana barang tersebut berada.
14. Sebagai Admin Sarpras, saya ingin mencatat kondisi barang sebagai breakdown angka (jumlah Baik, jumlah Rusak Ringan, jumlah Rusak Berat) yang totalnya harus sama dengan Jumlah Unit, sehingga kondisi barang massal tetap akurat direpresentasikan.
15. Sebagai Admin Sarpras, saya ingin mengedit data barang yang sudah ada, sehingga saya bisa memperbarui informasi jika ada perubahan.
16. Sebagai Admin Sarpras, saya ingin mengarsipkan (bukan menghapus permanen) barang yang sudah tidak ada/dipakai lagi, sehingga riwayat peminjaman dan laporan kerusakan yang terkait tetap utuh.
17. Sebagai Admin Sarpras, saya ingin mencari dan memfilter daftar barang (berdasarkan nama, kategori, lokasi, atau status kondisi), sehingga saya bisa cepat menemukan barang yang dicari.
18. Sebagai Admin Sarpras, saya ingin melihat detail satu barang beserta riwayat peminjaman dan riwayat laporan kerusakannya, sehingga saya punya gambaran lengkap riwayat barang tersebut.

### Peminjaman Internal (Jalur A)
19. Sebagai Admin Sarpras, saya ingin mencatat pengajuan peminjaman internal (nama peminjam, jabatan/kelas, no. HP, barang & jumlah yang dipinjam, tujuan, tanggal pinjam & rencana kembali), sehingga peminjaman dalam sekolah terdokumentasi.
20. Sebagai Admin Sarpras, saya ingin peminjaman internal langsung berstatus "Dipinjam" begitu saya input (tanpa tahap approval terpisah), sehingga alurnya singkat sesuai kebiasaan operasional sekolah.
21. Sebagai Admin Sarpras, saya ingin sistem otomatis mengurangi jumlah "tersedia" pada barang terkait saat peminjaman dicatat, sehingga stok yang bisa dipinjam selalu akurat.
22. Sebagai Admin Sarpras, saya ingin meng-upload foto kondisi awal barang secara opsional saat serah terima (terutama untuk barang bernilai/elektronik), sehingga ada bukti kondisi sebelum dipinjam untuk barang yang berisiko tinggi.
23. Sebagai Admin Sarpras, saya ingin mencatat pengembalian barang (tanggal aktual & foto kondisi akhir opsional), sehingga siklus peminjaman internal selesai dan stok tersedia bertambah kembali.
24. Sebagai Admin Sarpras, saya ingin sistem menandai peminjaman yang melewati tanggal rencana kembali tapi belum dikembalikan sebagai "Terlambat", sehingga saya bisa menindaklanjuti tanpa perlu mengecek manual satu per satu.

### Peminjaman Eksternal (Jalur B) & Surat Peminjaman
25. Sebagai Admin Sarpras, saya ingin mencatat pengajuan peminjaman eksternal dengan data tambahan (Tujuan Peminjaman, Lokasi Pemanfaatan, Tanggal Mulai & Kembali, Penanggung Jawab), sehingga kebutuhan administratif peminjaman ke luar sekolah terpenuhi.
26. Sebagai Admin Sarpras, saya ingin sistem otomatis membuatkan nomor surat berurutan (format resmi, reset tiap tahun) saat peminjaman eksternal dicatat, sehingga penomoran surat konsisten dan tidak ada duplikasi.
27. Sebagai Admin Sarpras, saya ingin mengunduh/mencetak Surat Peminjaman Barang dalam format PDF berkop/logo resmi SMK Cyber Media, sehingga surat siap dicetak dan ditandatangani manual (cap basah) sebagai bukti sah peminjaman ke luar.
28. Sebagai Admin Sarpras, saya ingin alur ambil/kembali & dampak ke stok pada peminjaman eksternal berlaku sama seperti peminjaman internal, sehingga konsistensi data terjaga di kedua jalur.

### Pelaporan Kerusakan & Pemeliharaan
29. Sebagai Admin Sarpras, saya ingin mencatat laporan kerusakan barang (memilih barang dari daftar/pencarian, deskripsi keluhan, upload foto bukti wajib), sehingga laporan yang diterima secara lisan/WA dari guru/siswa terdokumentasi di sistem.
30. Sebagai Admin Sarpras, saya ingin setiap laporan kerusakan memiliki status tiket (Laporan Masuk → Diproses/Diperbaiki → Selesai / Ganti Unit), sehingga saya bisa melacak progres penanganan.
31. Sebagai Admin Sarpras, saya ingin saat laporan berstatus "Selesai", jumlah pada breakdown kondisi barang terkait berpindah dari Rusak (Ringan/Berat) kembali ke Baik, sehingga data kondisi barang otomatis termutakhirkan.
32. Sebagai Admin Sarpras, saya ingin saat laporan berstatus "Ganti Unit", jumlah pada breakdown Rusak Berat barang terkait dikurangi dari total unit (write-off), sehingga barang yang benar-benar sudah tidak bisa dipakai keluar dari perhitungan stok aktif.
33. Sebagai Admin Sarpras, saya ingin mencatat penambahan unit pengganti secara manual (sebagai transaksi/​penambahan qty terpisah) setelah "Ganti Unit", sehingga stok barang pengganti tercatat sebagai entri baru yang jelas.
34. Sebagai Admin Sarpras, saya ingin melihat daftar semua tiket laporan kerusakan dengan filter status, sehingga saya bisa memprioritaskan penanganan.

### Dashboard & Pelaporan Pimpinan
35. Sebagai Admin Sarpras, saya ingin melihat dashboard ringkasan (total unit barang, distribusi status kelayakan, jumlah aset sedang dipinjam internal/eksternal, jumlah tiket perbaikan aktif, daftar peminjaman terlambat), sehingga saya punya gambaran kondisi sarpras secara sekilas.
36. Sebagai Admin Sarpras, saya ingin mencetak Laporan Inventaris Ruang (LIR) dalam format PDF per ruang, sehingga saya bisa menyerahkan laporan inventaris ke pimpinan atau untuk keperluan audit.
37. Sebagai Admin Sarpras, saya ingin mencetak/ekspor Rekap Peminjaman dan Riwayat Perbaikan dalam format PDF dan Excel, sehingga data bisa diserahkan ke pimpinan dalam format yang sesuai kebutuhan (cetak vs olah data lanjut).
38. Sebagai Admin Sarpras, saya ingin mencetak ulang Surat Peminjaman Luar Sekolah yang sudah pernah diterbitkan, sehingga saya tidak perlu membuat ulang jika salinan fisik hilang.

## Keputusan Implementasi

**Stack & Infrastruktur**
- Next.js (App Router) + Tailwind CSS untuk frontend & backend (route handlers/server actions).
- PostgreSQL sebagai database, diakses lewat Drizzle ORM.
- Deploy ke VPS; foto/file disimpan di local disk server (bukan object storage cloud).
- Auth: NextAuth.js (Auth.js) dengan Credentials Provider, password di-hash (bcrypt). Middleware melindungi seluruh route dashboard — hanya Admin Sarpras yang bisa mengakses.
- PDF: `@react-pdf/renderer`. Excel: `exceljs`.

**Model Peran**
- Satu-satunya role berlogin: **Admin Sarpras** (multi-akun). Tidak ada role Kakomli, Guru, Siswa, atau Pimpinan sebagai entitas login di sistem — mereka hanya muncul sebagai data (nama, kontak) di dalam record peminjaman/laporan yang diinput Admin.
- Tidak ada form publik/self-service. Seluruh input (peminjaman, laporan kerusakan) dilakukan oleh Admin Sarpras dari dashboard.

**Modul Utama**
1. **Auth & User Management** — login, CRUD akun staf Sarpras, pencatatan aktor pada setiap aksi (createdBy/updatedBy).
2. **Lokasi Hierarki** — 4 tabel/level relasional: Gedung, Lantai, Ruang, Sub-lokasi (opsional/nullable pada barang).
3. **Barang (Inventaris)** — model batch/quantity: satu baris data = satu jenis barang dengan Jumlah Unit total dan breakdown (Jumlah Baik, Jumlah Rusak Ringan, Jumlah Rusak Berat) yang harus selalu berjumlah sama dengan total. Kode barang input manual dengan validasi unik. Kategori sebagai field tambahan untuk filter/pengelompokan laporan. Status arsip (soft delete) alih-alih hard delete.
4. **Peminjaman** — satu entitas Peminjaman dengan field `jenis` (internal/eksternal) yang membedakan jalur; field khusus eksternal (tujuan, lokasi pemanfaatan, penanggung jawab, nomor surat) bersifat nullable untuk peminjaman internal. Tidak ada status approval — status langsung berjalan dari "Dipinjam" → "Dikembalikan". Field `tanggalRencanaKembali` dipakai untuk deteksi keterlambatan (dihitung on-the-fly dibanding tanggal hari ini, bukan job terjadwal).
5. **Generator Nomor Surat** — modul murni (deep module) yang menerima tahun berjalan & nomor terakhir yang dipakai pada tahun tersebut, mengembalikan nomor urut berikutnya dengan format resmi (`{urut}/SARPRAS/CY/{bulan romawi}/{tahun}`). Reset ke 001 saat tahun berganti. Dipanggil sinkron saat peminjaman eksternal dibuat (butuh strategi mencegah race condition duplikat nomor, misal transaksi database dengan lock/unique constraint per tahun+urut).
6. **Surat Peminjaman PDF** — komponen render terpisah dari logika generator nomor, menerima data peminjaman + nomor surat yang sudah digenerate, menghasilkan PDF berkop/logo sekolah dengan area tanda tangan kosong (TTD manual/cap basah, bukan TTD digital).
7. **Laporan Kerusakan (Ticketing)** — entitas Laporan terhubung ke satu Barang, dengan status enum (Masuk, Diproses, Selesai, Ganti Unit). Perubahan status memicu **Logika Stok Laporan Kerusakan** (deep module terpisah, lihat Keputusan Testing) yang memutasi breakdown kondisi barang terkait.
8. **Dashboard & Ringkasan** — kumpulan query agregasi read-only di atas data Barang, Peminjaman, dan Laporan.
9. **Export Laporan** — generator LIR per ruang (join Barang + Lokasi), generator rekap peminjaman/perbaikan (PDF via react-pdf, Excel via exceljs) dengan filter rentang tanggal.
10. **Upload Foto/File** — modul penyimpanan file ke disk lokal VPS dengan validasi tipe (jpg/png) dan ukuran maksimum; dipakai oleh modul Barang, Peminjaman (foto kondisi), dan Laporan Kerusakan (foto bukti).

**Kategori Barang**: field tambahan (di luar spesifikasi awal) untuk mendukung filter & pengelompokan pada dashboard/LIR — dikonfirmasi sebagai penambahan yang diterima user.

## Keputusan Testing

Test yang baik menguji **perilaku eksternal** modul (input → output/efek), bukan detail implementasi internal (query SQL spesifik, struktur internal state). Untuk proyek greenfield ini belum ada prior art di codebase — pola testing akan mengikuti konvensi standar Next.js/TypeScript (test runner: Vitest, dijalankan terhadap fungsi murni tanpa mock database bila memungkinkan).

Dua modul yang akan dites unit secara eksplisit karena keduanya adalah *deep module* dengan logika murni yang krusial dan rawan bug jika tidak diverifikasi:

1. **Generator Nomor Surat**
   - Input: tahun berjalan, nomor urut terakhir pada tahun tersebut (atau tidak ada/null jika tahun baru).
   - Output: nomor urut berikutnya + string nomor surat terformat.
   - Kasus yang harus dicakup: nomor pertama di tahun baru dimulai dari 001; nomor berikutnya di tahun yang sama increment benar; pergantian tahun mereset counter ke 001 meskipun nomor terakhir tahun sebelumnya besar; format bulan romawi & padding angka benar (misal 001 bukan 1).

2. **Logika Stok Laporan Kerusakan**
   - Input: breakdown kondisi barang saat ini (Baik/Rusak Ringan/Rusak Berat), jumlah yang dilaporkan rusak, status baru tiket (Diproses/Selesai/Ganti Unit).
   - Output: breakdown kondisi barang yang sudah dimutasi.
   - Kasus yang harus dicakup: transisi ke "Selesai" memindahkan jumlah dari Rusak kembali ke Baik dengan benar; transisi ke "Ganti Unit" mengurangi Rusak Berat dari total unit (write-off) tanpa memengaruhi kategori kondisi lain; total unit setelah mutasi tetap konsisten (tidak minus, tidak melebihi jumlah asal); mutasi tidak boleh dobel-terapkan jika status di-set ke nilai yang sama dua kali.

Modul lain (CRUD barang, peminjaman, auth, PDF/Excel rendering, upload file) akan diverifikasi lewat pengujian manual/integrasi saat implementasi, tidak dites unit secara eksplisit dalam PRD ini.

## Di Luar Cakupan

- Login/akun untuk Kakomli, Guru, Siswa, pihak luar sekolah, atau Pimpinan — semua interaksi mereka terjadi di luar sistem (lisan/WA) dan dicatatkan oleh Admin.
- Form publik/self-service untuk pengajuan peminjaman atau laporan kerusakan.
- Notifikasi otomatis (WhatsApp/email/push) untuk status approval, keterlambatan, atau progres laporan — hanya highlight visual di dashboard.
- Tanda tangan digital/e-signature pada Surat Peminjaman — tetap manual/cap basah.
- Pelacakan barang per-unit individual (serial number per unit fisik) — sistem memakai model batch/quantity.
- Integrasi dengan sistem BMN/BMD pemerintah atau standar penomoran aset resmi eksternal.
- Object storage cloud (S3/Supabase/R2) — foto disimpan di disk lokal VPS.
- Aplikasi mobile native — hanya web responsive.
- QR Code untuk pelaporan kerusakan (spesifikasi awal secara eksplisit menyatakan tanpa QR Code).

## Catatan Tambahan

- Karena tidak ada tahap approval, kolom `status` pada Peminjaman lebih sederhana dari desain birokrasi khas instansi pemerintah — ini keputusan sadar untuk menyesuaikan dengan alur kerja riil Admin Sarpras yang sudah menerima konfirmasi verbal sebelum input ke sistem.
- Keputusan model batch/quantity (bukan per-unit) berarti riwayat peminjaman/kerusakan terikat ke *jenis barang*, bukan ke unit fisik spesifik. Jika di masa depan dibutuhkan pelacakan per-unit (misal untuk barang sangat bernilai seperti kamera individual), ini akan jadi perubahan skema yang cukup besar dan sebaiknya dibahas sebagai PRD terpisah.
- Race condition pada Generator Nomor Surat perlu penanganan konkuren yang hati-hati (dua peminjaman eksternal dicatat nyaris bersamaan) — didetailkan sebagai bagian dari implementasi modul, bukan hanya test logika angkanya saja.
